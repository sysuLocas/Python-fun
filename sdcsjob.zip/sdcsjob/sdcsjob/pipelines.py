# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
import datetime

class SdcsjobPipeline(object):
    def __init__(self):
        self.file = open('jobitems.txt', 'wb')
    def process_item(self, item, spider):
        now=datetime.datetime.now().strftime('%Y-%m-%d')
        date=item['date'][0].encode("utf8").strip()
        if(date == now):
            title=item['title'][0].encode("utf8").strip()
            url=item['url'][0].encode("utf8").strip()
            temp="<a href=\""+url+"\">"+title+"</a>"
            self.file.write(temp)
            self.file.write(" ")
            self.file.write(date)
            self.file.write("<br>\r\n")
        return item
