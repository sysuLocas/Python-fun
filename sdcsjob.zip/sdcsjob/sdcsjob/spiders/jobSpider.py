# -*- coding: utf-8 -*-
import scrapy
from sdcsjob.items import SdcsjobItem
from scrapy.selector import HtmlXPathSelector
class jobSpider(scrapy.Spider):
    name = "sdcsjob"
    allowed_domains = ["sdcs.sysu.edu.cn"]
    start_urls = [
        "http://sdcs.sysu.edu.cn/?cat=63",
        ]
    
    def parse(self, response):#调用这个方法解析网页内容，同时需要返回下一个需要抓取的网页，或者返回items列表
        if response.status == 200:
            hxs = HtmlXPathSelector(response)
            jobnewslist = hxs.select('//li/h2')
            for news in jobnewslist:
                item = SdcsjobItem()
                item['title'] = news.select('a/text()').extract()
                item['url'] = news.select('a/@href').extract()
                item['date']= news.select('span/text()').extract()
                yield item
